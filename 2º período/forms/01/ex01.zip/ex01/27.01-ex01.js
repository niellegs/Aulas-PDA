function logar() {
    groceries = window.document.getElementById('groceries_list').style.display='block'
}