// igualdade
var a = 2
//  '=' atribui um valor
var b = 5
console.log(a == b)
// '==' compara o valor
console.log(a === b)
// '===' compara o valor e o tipo

// menor
var c = 5
var d = 4
console.log(c < d)
// maior
console.log(c > d)

// módulo
console.log(10 % 2)
// mostra o resto da divisão entre 10 e 2
console.log(10 / 2)
// mostra adivisão entre 10 e 2