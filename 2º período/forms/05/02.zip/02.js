frase = 'olá';

if( frase == 'olá') {
    console.log('olá')
} else if(frase == 'adeus') {
    console.log('adeus')
}